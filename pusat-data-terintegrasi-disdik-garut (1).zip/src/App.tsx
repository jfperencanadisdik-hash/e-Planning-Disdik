import React, { useState, useRef, useEffect } from 'react';
import { 
  UploadCloud, 
  LayoutDashboard, 
  Settings, 
  LogOut, 
  FileText, 
  HardDrive,
  CheckCircle,
  X,
  AlertCircle,
  Menu,
  Bell,
  Search,
  Building,
  Shapes,
  BookOpen,
  GraduationCap,
  BookA,
  FolderOpen,
  Sparkles,
  Bot,
  Copy,
  Loader2,
  FileSpreadsheet,
  ExternalLink,
  RefreshCw,
  TrendingUp,
  Download,
  Eye,
  LogIn
} from 'lucide-react';
import { signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { collection, addDoc, onSnapshot, query, orderBy, serverTimestamp, doc, setDoc, getDoc } from 'firebase/firestore';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { auth, db, storage, googleProvider } from '../firebase';

// --- Helper Gemini API (Backend) ---
const callGeminiAPI = async (prompt: string, systemInstruction: string = "") => {
  const url = `/api/ai/generate`;
  
  const payload: any = {
    prompt,
    systemInstruction
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const data = await response.json();
    return data.text || "Maaf, tidak ada respons yang dihasilkan.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Gagal terhubung ke AI. Silakan coba lagi.");
  }
};

// --- Struktur Folder Hierarki Disdik Garut ---
const FOLDER_STRUCTURE: Record<string, { name: string, subFolders: string[] }> = {
  sekretariat: {
    name: "Sekretariat",
    subFolders: ["Bagian Umum", "Bagian Keuangan", "Bagian Kepegawaian", "Bagian Perencanaan"]
  },
  paud: {
    name: "Bidang PAUD-Dikmas",
    subFolders: ["Seksi PAUD", "Seksi Dikmas"]
  },
  sd: {
    name: "Bidang SD",
    subFolders: ["Seksi Kelembagaan dan Kesiswaan", "Seksi Kurikulum", "Seksi Sarana Prasarana"]
  },
  smp: {
    name: "Bidang SMP",
    subFolders: ["Seksi Kelembagaan dan Kesiswaan", "Seksi Kurikulum", "Seksi Sarana Prasarana"]
  },
  ketenagaan: {
    name: "Bidang KPBS",
    subFolders: ["Seksi Ketenagaan", "Seksi Pengembangan Bahasa dan Sastra"]
  }
};

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [uploadedFiles, setUploadedFiles] = useState<any[]>([]);
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
      
      if (currentUser) {
        // Ensure user profile exists in Firestore
        const userRef = doc(db, 'users', currentUser.uid);
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          try {
            await setDoc(userRef, {
              email: currentUser.email,
              name: currentUser.displayName || 'User',
              role: 'sekretariat', // Default role
              createdAt: serverTimestamp()
            });
          } catch (e) {
            console.error("Error creating user profile:", e);
          }
        }
      }
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (isAuthReady && user) {
      const q = query(collection(db, 'files'), orderBy('uploadDate', 'desc'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const filesData = snapshot.docs.map(doc => {
          const data = doc.data();
          return {
            id: doc.id,
            ...data,
            status: data.status || 'Tersedia',
            // Convert Firestore timestamp to string for UI
            uploadDate: data.uploadDate?.toDate().toLocaleString('id-ID') || new Date().toLocaleString('id-ID')
          };
        });
        setUploadedFiles(filesData);
      }, (error) => {
        console.error("Firestore Error: ", error);
      });
      return () => unsubscribe();
    } else {
      setUploadedFiles([]);
    }
  }, [isAuthReady, user]);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      try {
        localStorage.removeItem('driveTokens');
      } catch (e) {
        console.warn('localStorage is not available', e);
      }
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  if (!isAuthReady) {
    return <div className="flex h-screen items-center justify-center bg-slate-50"><Loader2 className="animate-spin text-blue-600" size={40} /></div>;
  }

  if (!user) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-50 font-sans">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full text-center border border-slate-100">
          <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-6">
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/9/9c/Logo_of_Ministry_of_Education_and_Culture_of_Republic_of_Indonesia.svg" 
              alt="Logo" 
              className="w-12 h-12 object-contain"
            />
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mb-2">Pusat Data Terintegrasi</h1>
          <p className="text-slate-500 mb-8">Dinas Pendidikan Kabupaten Garut</p>
          <button 
            onClick={handleLogin}
            className="w-full flex items-center justify-center gap-3 bg-blue-600 text-white py-3 px-4 rounded-xl font-medium hover:bg-blue-700 transition-colors shadow-sm shadow-blue-600/20"
          >
            <LogIn size={20} />
            Masuk dengan Akun Google
          </button>
        </div>
      </div>
    );
  }

  // Filter files based on search query
  const filteredFiles = uploadedFiles.filter(file => 
    file.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    file.aiDescription?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    file.seksiName?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Helper untuk mendapatkan nama lengkap tab aktif
  const getTabName = (tab: string) => {
    const tabs: Record<string, string> = {
      sekretariat: 'Sekretariat',
      paud: 'Bidang PAUD-Dikmas',
      sd: 'Bidang SD',
      smp: 'Bidang SMP',
      ketenagaan: 'Bidang Ketenagaan, Pengembangan Bahasa dan Sastra'
    };
    return tabs[tab] || '';
  };

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-800">
      {/* Sidebar */}
      <aside 
        className={`${
          isSidebarOpen ? 'w-72' : 'w-20'
        } bg-blue-900 text-white transition-all duration-300 ease-in-out flex flex-col shadow-xl z-20 shrink-0`}
      >
        <div className="h-16 flex items-center justify-center border-b border-blue-800 px-4 shrink-0">
          <div className="flex items-center gap-3 w-full justify-center">
            <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shrink-0 p-1">
              <img 
                src="https://upload.wikimedia.org/wikipedia/commons/9/9c/Logo_of_Ministry_of_Education_and_Culture_of_Republic_of_Indonesia.svg" 
                alt="Logo Tut Wuri Handayani" 
                className="w-full h-full object-contain"
              />
            </div>
            {isSidebarOpen && (
              <div className="flex flex-col overflow-hidden">
                <span className="font-bold text-sm leading-tight truncate">Pusat Data Terintegrasi</span>
                <span className="text-xs text-blue-300 truncate">Disdik Kab. Garut</span>
              </div>
            )}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto py-6 flex flex-col gap-6 px-3 custom-scrollbar">
          {/* Menu Utama */}
          <div className="flex flex-col gap-1">
            {isSidebarOpen && <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider px-3 mb-2">Utama</span>}
            <NavItem icon={<LayoutDashboard size={20} />} label="Beranda" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} isOpen={isSidebarOpen} />
            <NavItem icon={<UploadCloud size={20} />} label="Unggah Data Pusat" active={activeTab === 'upload'} onClick={() => setActiveTab('upload')} isOpen={isSidebarOpen} />
            <NavItem 
              icon={<Sparkles size={20} className="text-amber-300" />} 
              label="Asisten AI" 
              active={activeTab === 'ai_assistant'} 
              onClick={() => setActiveTab('ai_assistant')} 
              isOpen={isSidebarOpen} 
              className={activeTab === 'ai_assistant' ? 'bg-amber-600/20 border border-amber-500/30' : 'hover:bg-amber-900/40 text-amber-100'}
            />
          </div>

          {/* Unit Kerja / Bidang */}
          <div className="flex flex-col gap-1">
            {isSidebarOpen && <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider px-3 mb-2">Unit Kerja</span>}
            <NavItem icon={<Building size={20} />} label="Sekretariat" active={activeTab === 'sekretariat'} onClick={() => setActiveTab('sekretariat')} isOpen={isSidebarOpen} />
            <NavItem icon={<Shapes size={20} />} label="Bidang PAUD-Dikmas" active={activeTab === 'paud'} onClick={() => setActiveTab('paud')} isOpen={isSidebarOpen} />
            <NavItem icon={<BookOpen size={20} />} label="Bidang SD" active={activeTab === 'sd'} onClick={() => setActiveTab('sd')} isOpen={isSidebarOpen} />
            <NavItem icon={<GraduationCap size={20} />} label="Bidang SMP" active={activeTab === 'smp'} onClick={() => setActiveTab('smp')} isOpen={isSidebarOpen} />
            <NavItem icon={<BookA size={20} />} label="Bidang KPBS" active={activeTab === 'ketenagaan'} onClick={() => setActiveTab('ketenagaan')} isOpen={isSidebarOpen} fullLabel="Bidang Ketenagaan, Pengembangan Bahasa dan Sastra" />
          </div>
        </div>

        <div className="p-4 border-t border-blue-800 shrink-0">
          <NavItem icon={<Settings size={20} />} label="Pengaturan" active={false} isOpen={isSidebarOpen} onClick={() => {}} />
          <NavItem icon={<LogOut size={20} />} label="Keluar" active={false} isOpen={isSidebarOpen} onClick={handleLogout} className="text-red-300 hover:bg-red-500/10 hover:text-red-200 mt-1" />
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden bg-slate-50/50">
        {/* Header */}
        <header className="h-16 bg-white shadow-sm flex items-center justify-between px-6 z-10 shrink-0 border-b border-slate-200">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 rounded-md hover:bg-slate-100 text-slate-600 transition-colors"
            >
              <Menu size={20} />
            </button>
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari file, laporan, atau nama sekolah..." 
                className="pl-10 pr-4 py-2 bg-slate-100 border-transparent focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-200 rounded-lg text-sm w-80 transition-all outline-none"
              />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button className="relative p-2 rounded-full hover:bg-slate-100 text-slate-600 transition-colors">
              <Bell size={20} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="flex items-center gap-3 border-l pl-4 border-slate-200">
              <div className="hidden md:block text-right">
                <p className="text-sm font-semibold text-slate-700 leading-tight">{user.displayName || 'Pengguna'}</p>
                <p className="text-xs text-slate-500">{user.email}</p>
              </div>
              <div className="h-9 w-9 rounded-full bg-blue-600 border-2 border-blue-100 flex items-center justify-center text-white font-semibold shadow-sm overflow-hidden">
                {user.photoURL ? <img src={user.photoURL} alt="Avatar" /> : user.displayName?.charAt(0) || 'U'}
              </div>
            </div>
          </div>
        </header>

        {/* Dynamic Content Area */}
        <div className="flex-1 overflow-auto p-6 md:p-8 relative">
          <div className="max-w-6xl mx-auto h-full">
            {activeTab === 'dashboard' && <DashboardView uploadedFiles={filteredFiles} />}
            {activeTab === 'upload' && <UploadView user={user} />}
            {activeTab === 'ai_assistant' && <AIAssistantView />}
            {['sekretariat', 'paud', 'sd', 'smp', 'ketenagaan'].includes(activeTab) && (
              <BidangView title={getTabName(activeTab)} unitKey={activeTab} uploadedFiles={filteredFiles} />
            )}
          </div>
        </div>
      </main>

      {/* Tambahan CSS */}
      <style dangerouslySetInnerHTML={{__html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.2);
          border-radius: 10px;
        }
        .custom-scrollbar:hover::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.4);
        }
        .content-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .content-scrollbar::-webkit-scrollbar-track {
          background: #f1f5f9;
        }
        .content-scrollbar::-webkit-scrollbar-thumb {
          background: #cbd5e1;
          border-radius: 10px;
        }
      `}} />
    </div>
  );
}

/* --- Komponen Pendukung --- */
const FileStatusBadge = ({ status }: { status: string }) => {
  if (status === 'Tersedia') {
    return (
      <span className="flex items-center gap-1 text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 font-medium">
        <CheckCircle size={12} /> Tersedia
      </span>
    );
  } else if (status === 'Menunggu Sinkronisasi') {
    return (
      <span className="flex items-center gap-1 text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-100 font-medium">
        <RefreshCw size={12} className="animate-spin-slow" /> Menunggu Sinkronisasi
      </span>
    );
  } else if (status === 'Perlu Tinjauan') {
    return (
      <span className="flex items-center gap-1 text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-100 font-medium">
        <AlertCircle size={12} /> Perlu Tinjauan
      </span>
    );
  }
  return (
    <span className="flex items-center gap-1 text-slate-600 bg-slate-50 px-2 py-0.5 rounded border border-slate-100 font-medium">
      <FileText size={12} /> {status}
    </span>
  );
};

const NavItem = ({ icon, label, active, onClick, isOpen, fullLabel, className = '' }: any) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-3 p-3 rounded-lg transition-colors w-full relative group ${
      active && !className.includes('bg-amber')
        ? 'bg-blue-800 text-white shadow-sm' 
        : !className ? 'text-blue-100 hover:bg-blue-800/50 hover:text-white' : ''
    } ${!isOpen && 'justify-center'} ${className}`}
    title={fullLabel || label}
  >
    <div className="shrink-0">{icon}</div>
    {isOpen && (
      <span className="font-medium text-sm text-left truncate leading-tight">
        {label}
      </span>
    )}
    {!isOpen && (
      <div className="absolute left-14 bg-slate-800 text-white text-xs px-2 py-1 rounded opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all whitespace-nowrap z-50">
        {fullLabel || label}
      </div>
    )}
  </button>
);

/* --- View: AI Assistant (Draf Surat) --- */
const AIAssistantView = () => {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setIsLoading(true);
    setError('');
    
    const systemInstruction = "Anda adalah Asisten Administratif AI profesional untuk Dinas Pendidikan Kabupaten Garut. Tugas utama Anda adalah membantu staf membuat draf surat resmi pemerintah (seperti Surat Edaran, Nota Dinas, Surat Keputusan, atau Undangan). Gunakan format surat resmi instansi pemerintahan di Indonesia. Gunakan bahasa Indonesia yang baku, formal, dan sopan.";
    const userPrompt = `Buatkan draf dokumen berdasarkan informasi berikut:\n\nTopik/Kebutuhan: ${prompt}\n\nBerikan langsung teks suratnya dengan tata letak yang rapi.`;

    try {
      const result = await callGeminiAPI(userPrompt, systemInstruction);
      setResponse(result);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    try {
      navigator.clipboard.writeText(response);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10 flex flex-col h-full">
      <div>
        <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
          Asisten AI Disdik <Sparkles className="text-amber-500" size={24} />
        </h1>
        <p className="text-slate-500 text-sm mt-1">Gunakan kecerdasan buatan untuk menyusun draf Surat Dinas, Nota Dinas, atau Surat Edaran secara otomatis.</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-[500px]">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 flex flex-col h-full">
          <label className="block text-sm font-semibold text-slate-700 mb-2">Instruksi Dokumen</label>
          <textarea
            className="w-full flex-1 p-4 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 focus:ring-amber-500 focus:border-amber-500 outline-none resize-none"
            placeholder="Contoh: Buatkan draf surat edaran untuk seluruh Kepala Sekolah SD di Kabupaten Garut tentang pelaksanaan libur awal Ramadhan tahun 2026. Surat ditandatangani oleh Kepala Dinas Pendidikan."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          ></textarea>
          <button 
            onClick={handleGenerate}
            disabled={isLoading || !prompt.trim()}
            className="mt-4 w-full flex justify-center items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-600 text-white font-medium rounded-lg hover:from-amber-600 hover:to-orange-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-sm shadow-amber-500/20"
          >
            {isLoading ? <Loader2 className="animate-spin" size={20} /> : <Bot size={20} />}
            {isLoading ? 'Menyusun Draf...' : 'Mulai Buat Draf ✨'}
          </button>
          {error && (
            <div className="mt-4 p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100 flex items-start gap-2">
              <AlertCircle size={16} className="mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col h-full overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
            <h3 className="font-semibold text-slate-700 flex items-center gap-2">
              <FileText size={18} className="text-blue-500" />
              Hasil Draf Dokumen
            </h3>
            {response && (
              <button 
                onClick={copyToClipboard}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 text-slate-600 text-xs font-medium rounded hover:bg-slate-50 transition-colors shadow-sm"
              >
                <Copy size={14} /> Salin Teks
              </button>
            )}
          </div>
          <div className="flex-1 p-6 overflow-y-auto content-scrollbar bg-white">
            {response ? (
              <div className="prose prose-sm max-w-none text-slate-700 whitespace-pre-wrap font-serif leading-relaxed">
                {response}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 gap-3">
                <Bot size={48} className="text-slate-200" />
                <p>Ketik instruksi di samping dan klik tombol buat draf.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

/* --- View: Folder / Bidang Tertentu --- */
const BidangView = ({ title, unitKey, uploadedFiles = [] }: any) => {
  // Memfilter file yang hanya ditujukan ke unit kerja ini
  const unitFiles = uploadedFiles.filter((f: any) => f.unitKey === unitKey);

  // Fungsi untuk mengunduh file
  const handleDownload = (file: any) => {
    if (file.fileUrl) {
      window.open(file.fileUrl, '_blank');
    } else if (file.fileObj) {
      const url = URL.createObjectURL(file.fileObj);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  // Fungsi untuk melihat file di tab baru
  const handleView = (file: any) => {
    if (file.fileUrl) {
      window.open(file.fileUrl, '_blank');
    } else if (file.fileObj) {
      const url = URL.createObjectURL(file.fileObj);
      window.open(url, '_blank');
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 h-full flex flex-col pb-10">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">{title}</h1>
          <p className="text-slate-500 text-sm mt-1">Manajemen data dan dokumen khusus unit kerja</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors shadow-sm">
          <FolderOpen size={16} className="text-blue-600" />
          Buka di Google Drive
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex-1 flex flex-col">
        <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
          <h3 className="font-semibold text-slate-800 flex items-center gap-2">
            <FileText size={18} className="text-blue-500" />
            Arsip Dokumen Terunggah
          </h3>
          <span className="text-sm text-slate-500 font-medium">{unitFiles.length} File Baru</span>
        </div>
        
        <div className="flex-1 p-0 overflow-auto content-scrollbar">
          {unitFiles.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 p-10">
              <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-3 border border-slate-100">
                <FolderOpen size={32} className="text-slate-300" />
              </div>
              <p>Belum ada data yang diunggah ke direktori ini pada sesi ini.</p>
              <p className="text-sm mt-1">Silakan gunakan menu "Unggah Data Pusat" terlebih dahulu.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-xs uppercase tracking-wider">
                    <th className="p-4 font-medium">Nama File</th>
                    <th className="p-4 font-medium">Seksi</th>
                    <th className="p-4 font-medium">Ukuran</th>
                    <th className="p-4 font-medium">Tanggal</th>
                    <th className="p-4 font-medium">Status</th>
                    <th className="p-4 font-medium text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {unitFiles.map((file: any) => (
                    <tr key={file.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-blue-50 rounded-lg shrink-0 border border-blue-100">
                            <FileText size={16} className="text-blue-600" />
                          </div>
                          <div>
                            <p className="font-semibold text-slate-800 text-sm">{file.name}</p>
                            {file.aiDescription && (
                              <p className="text-xs text-slate-500 mt-1 line-clamp-1" title={file.aiDescription}>
                                <Sparkles size={10} className="inline text-amber-500 mr-1" />
                                {file.aiDescription}
                              </p>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-sm text-slate-600">
                        <span className="font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded">{file.seksiName}</span>
                      </td>
                      <td className="p-4 text-sm text-slate-600">{file.size}</td>
                      <td className="p-4 text-sm text-slate-600">{file.uploadDate}</td>
                      <td className="p-4">
                        <FileStatusBadge status={file.status} />
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => handleView(file)}
                            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-white border border-slate-200 text-slate-600 text-xs font-medium rounded hover:bg-slate-50 hover:text-blue-600 transition-colors shadow-sm"
                          >
                            <Eye size={14} /> Lihat
                          </button>
                          <button 
                            onClick={() => handleDownload(file)}
                            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-blue-600 text-white text-xs font-medium rounded hover:bg-blue-700 transition-colors shadow-sm"
                          >
                            <Download size={14} /> Unduh
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

/* --- View: Dashboard Utama --- */
const DashboardView = ({ uploadedFiles = [] }: any) => {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState('10 menit yang lalu');
  const [driveConnected, setDriveConnected] = useState(false);
  const [driveEmail, setDriveEmail] = useState<string | null>(null);

  useEffect(() => {
    // Check initial drive status
    let tokens = null;
    try {
      tokens = localStorage.getItem('driveTokens');
    } catch (e) {
      console.warn('localStorage is not available', e);
    }
    
    if (tokens) {
      fetch('/api/drive/status', {
        headers: {
          'Authorization': `Bearer ${tokens}`
        }
      })
        .then(res => res.json())
        .then(data => {
          setDriveConnected(data.connected);
          if (data.email) setDriveEmail(data.email);
        })
        .catch(err => console.error("Failed to check drive status", err));
    }

    // Listen for OAuth success messages
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        setDriveConnected(true);
        if (event.data.email) {
          setDriveEmail(event.data.email);
        }
        if (event.data.tokens) {
          try {
            localStorage.setItem('driveTokens', JSON.stringify(event.data.tokens));
          } catch (e) {
            console.warn('localStorage is not available', e);
          }
        }
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const handleConnectDrive = async () => {
    try {
      const redirectUri = `${window.location.origin}/auth/callback`;
      const response = await fetch(`/api/auth/drive/url?redirectUri=${encodeURIComponent(redirectUri)}`);
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to get auth URL');
      }
      
      const authWindow = window.open(
        data.url,
        'oauth_popup',
        'width=600,height=700'
      );

      if (!authWindow) {
        alert('Tolong izinkan pop-up untuk menghubungkan akun Google Drive.');
      }
    } catch (error: any) {
      console.error('OAuth error:', error);
      alert('Gagal memulai koneksi Google Drive: ' + error.message);
    }
  };
  
  const katalogData = [
    {
      id: 'sekretariat',
      bidang: 'Sekretariat',
      icon: <Building className="text-purple-600" size={24} />,
      bgIcon: 'bg-purple-100',
      border: 'border-purple-200',
      items: [
        { nama: 'Dokumen Perencanaan (RKA, DPA, Renstra)', detail: '45 Berkas', status: 'ready' },
        { nama: 'Laporan Keuangan & SPJ', detail: '128 Berkas', status: 'ready' },
        { nama: 'Data Kepegawaian & Aset Kantor (KIR)', detail: 'Menunggu Update', status: 'syncing' }
      ]
    },
    {
      id: 'paud',
      bidang: 'Bidang PAUD & Dikmas',
      icon: <Shapes className="text-pink-600" size={24} />,
      bgIcon: 'bg-pink-100',
      border: 'border-pink-200',
      items: [
        { nama: 'Dapodik PAUD & Izin Operasional', detail: '856 Lembaga', status: 'ready' },
        { nama: 'Penyaluran BOP PAUD & Kesetaraan', detail: 'Sinkronisasi Aktif', status: 'ready' },
        { nama: 'Peserta Didik (TK/KB/Paket A,B,C)', detail: '14.240 Siswa', status: 'ready' }
      ]
    },
    {
      id: 'sd',
      bidang: 'Bidang SD (Sekolah Dasar)',
      icon: <BookOpen className="text-blue-600" size={24} />,
      bgIcon: 'bg-blue-100',
      border: 'border-blue-200',
      items: [
        { nama: 'Data Siswa Penerima PIP SD', detail: '12.450 Siswa', status: 'ready' },
        { nama: 'Penyaluran Dana BOS & ANBK SD', detail: 'Terverifikasi', status: 'ready' },
        { nama: 'Data Sarpras & Usulan Rehab Gedung', detail: 'Perlu Tinjauan', status: 'syncing' }
      ]
    },
    {
      id: 'smp',
      bidang: 'Bidang SMP',
      icon: <GraduationCap className="text-emerald-600" size={24} />,
      bgIcon: 'bg-emerald-100',
      border: 'border-emerald-200',
      items: [
        { nama: 'Data Siswa & Hasil PPDB SMP', detail: '4.850 Siswa', status: 'ready' },
        { nama: 'Penyaluran BOS & Pelaksanaan ANBK', detail: 'Terverifikasi', status: 'ready' },
        { nama: 'Usulan Rehab & Lab Komputer', detail: '56 Proposal', status: 'ready' }
      ]
    },
    {
      id: 'ketenagaan',
      bidang: 'Bidang KPBS',
      icon: <BookA className="text-amber-600" size={24} />,
      bgIcon: 'bg-amber-100',
      border: 'border-amber-200',
      items: [
        { nama: 'Database Guru (PNS, PPPK, Honorer)', detail: '15.240 Pegawai', status: 'ready' },
        { nama: 'Penerima Tunjangan Profesi (TPG)', detail: 'Sinkronisasi BKN', status: 'syncing' },
        { nama: 'Revitalisasi Bahasa & Laporan FTBI', detail: '24 Dokumen', status: 'ready' }
      ]
    }
  ];

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      setLastUpdated('Baru saja');
    }, 1500);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Katalog Data Terpusat</h1>
          <p className="text-slate-500 text-sm mt-1">Status ketersediaan dokumen dan data dari setiap unit kerja</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-2 text-sm bg-white border border-slate-200 text-slate-700 px-4 py-2 rounded-lg hover:bg-slate-50 transition-all shadow-sm disabled:opacity-50 font-medium"
          >
            <RefreshCw size={16} className={isRefreshing ? "animate-spin text-blue-600" : "text-slate-500"} />
            <span>{isRefreshing ? 'Memindai Drive...' : 'Pindai Ulang Drive'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard icon={<FolderOpen className="text-blue-600" />} title="Total Dokumen Terarsip" value={(5842 + uploadedFiles.length).toLocaleString('id-ID')} trend={`+${uploadedFiles.length} Sesi Ini`} trendUp={true} subtitle="" />
        <StatCard icon={<CheckCircle className="text-emerald-600" />} title="Integritas Data" value="94%" subtitle="Data sinkron dengan Dapodik" trend="" trendUp={false} />
        <StatCard icon={<HardDrive className="text-amber-600" />} title="Status Google Drive" value="Terhubung" subtitle={`Pembaruan terakhir: ${lastUpdated}`} trend="" trendUp={false} />
      </div>
      
      {/* Tambahan Info Akun Sistem */}
      <div className="mt-6 bg-gradient-to-br from-blue-900 to-indigo-900 p-6 rounded-xl shadow-sm text-white relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-lg font-semibold mb-2">Sinkronisasi Google Drive</h2>
            {driveConnected ? (
              <>
                <p className="text-sm text-blue-100 mb-4">Akun pengarsipan terhubung: {driveEmail || 'pdatagarut@gmail.com'}</p>
                <div className="flex items-center gap-2 bg-white/10 w-fit px-3 py-1.5 rounded-lg border border-white/20 backdrop-blur-sm">
                  <CheckCircle size={16} className="text-green-400" />
                  <span className="text-xs font-medium">Status API: Online</span>
                </div>
              </>
            ) : (
              <>
                <p className="text-sm text-blue-100 mb-4">Belum ada akun Google Drive yang dihubungkan.</p>
                <button 
                  onClick={handleConnectDrive}
                  className="flex items-center gap-2 bg-white text-blue-900 px-4 py-2 rounded-lg font-medium text-sm hover:bg-blue-50 transition-colors shadow-sm"
                >
                  <HardDrive size={16} />
                  Hubungkan Google Drive
                </button>
              </>
            )}
          </div>
        </div>
        <HardDrive size={100} className="absolute -bottom-6 -right-6 text-white/10 rotate-12" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mt-6">
        {katalogData.map((bidang) => (
          <div key={bidang.id} className={`bg-white rounded-xl shadow-sm border ${bidang.border} overflow-hidden hover:shadow-md transition-shadow flex flex-col`}>
            <div className="p-5 border-b border-slate-100 flex items-center gap-4 bg-slate-50/50">
              <div className={`p-3 rounded-lg ${bidang.bgIcon} shrink-0`}>
                {bidang.icon}
              </div>
              <div>
                <h2 className="font-bold text-slate-800 leading-tight">{bidang.bidang}</h2>
                <button className="text-xs text-blue-600 font-medium hover:underline mt-0.5 flex items-center gap-1">
                  Buka Folder <ExternalLink size={10} />
                </button>
              </div>
            </div>
            <div className="p-5 flex-1">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">Cakupan Data Utama</h3>
              <ul className="space-y-4">
                {bidang.items.map((item, index) => (
                  <li key={index} className="flex items-start justify-between gap-3 group">
                    <div className="flex flex-col">
                      <span className="text-sm font-medium text-slate-700 group-hover:text-blue-600 transition-colors line-clamp-2 leading-snug">
                        {item.nama}
                      </span>
                      <span className="text-xs text-slate-500 mt-1">{item.detail}</span>
                    </div>
                    <div className="shrink-0 mt-0.5">
                      {item.status === 'ready' ? (
                        <div title="Data Tersedia & Tersinkronisasi" className="bg-emerald-100 p-1.5 rounded-full text-emerald-600">
                          <CheckCircle size={14} />
                        </div>
                      ) : (
                        <div title="Menunggu Pembaruan/Sinkronisasi" className="bg-amber-100 p-1.5 rounded-full text-amber-600 animate-pulse">
                          <RefreshCw size={14} />
                        </div>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>

      {/* File Terbaru */}
      <div className="mt-8 bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
        <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
          <h3 className="font-semibold text-slate-800 flex items-center gap-2">
            <FileText size={18} className="text-blue-500" />
            File Terbaru
          </h3>
          <span className="text-sm text-slate-500 font-medium">{uploadedFiles.length} File Total</span>
        </div>
        
        <div className="p-0 overflow-auto content-scrollbar max-h-96">
          {uploadedFiles.length === 0 ? (
            <div className="flex flex-col items-center justify-center text-slate-400 p-10">
              <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-3 border border-slate-100">
                <FolderOpen size={32} className="text-slate-300" />
              </div>
              <p>Belum ada data yang diunggah.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-xs uppercase tracking-wider">
                    <th className="p-4 font-medium">Nama File</th>
                    <th className="p-4 font-medium">Seksi</th>
                    <th className="p-4 font-medium">Ukuran</th>
                    <th className="p-4 font-medium">Tanggal</th>
                    <th className="p-4 font-medium">Status</th>
                    <th className="p-4 font-medium text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {uploadedFiles.slice(0, 5).map((file: any) => (
                    <tr key={file.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-blue-50 rounded-lg shrink-0 border border-blue-100">
                            <FileText size={16} className="text-blue-600" />
                          </div>
                          <div>
                            <p className="font-semibold text-slate-800 text-sm">{file.name}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-sm text-slate-600">
                        <span className="font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded">{file.seksiName}</span>
                      </td>
                      <td className="p-4 text-sm text-slate-600">{file.size}</td>
                      <td className="p-4 text-sm text-slate-600">{file.uploadDate}</td>
                      <td className="p-4">
                        <FileStatusBadge status={file.status} />
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => {
                              if (file.fileUrl) window.open(file.fileUrl, '_blank');
                            }}
                            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-white border border-slate-200 text-slate-600 text-xs font-medium rounded hover:bg-slate-50 hover:text-blue-600 transition-colors shadow-sm"
                          >
                            <Eye size={14} /> Lihat
                          </button>
                          <button 
                            onClick={() => {
                              if (file.fileUrl) window.open(file.fileUrl, '_blank');
                            }}
                            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-blue-600 text-white text-xs font-medium rounded hover:bg-blue-700 transition-colors shadow-sm"
                          >
                            <Download size={14} /> Unduh
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon, title, value, trend, trendUp, subtitle }: any) => (
  <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-between hover:shadow-md transition-shadow">
    <div className="flex justify-between items-start mb-4">
      <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">{icon}</div>
      {trend && (
        <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${trendUp ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
          {trend}
        </span>
      )}
    </div>
    <div>
      <p className="text-slate-500 text-sm font-medium">{title}</p>
      <div className="flex items-baseline gap-2 mt-1">
        <h3 className="text-2xl font-bold text-slate-800">{value}</h3>
      </div>
      {subtitle && <p className="text-xs text-slate-500 mt-1">{subtitle}</p>}
    </div>
  </div>
);

/* --- View: Upload ke Google Drive dengan Hierarki Sub-Folder --- */
const UploadView = ({ user }: any) => {
  const [dragActive, setDragActive] = useState(false);
  const [files, setFiles] = useState<any[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  
  // State Bertingkat untuk Folder Structure
  const [selectedBidang, setSelectedBidang] = useState('sekretariat');
  const [selectedSeksi, setSelectedSeksi] = useState(FOLDER_STRUCTURE['sekretariat'].subFolders[0]);
  
  const [analyzingId, setAnalyzingId] = useState<string | null>(null); 
  const inputRef = useRef<HTMLInputElement>(null);

  // Penanganan Perubahan Bidang -> Otomatis reset dropdown Seksi
  const handleBidangChange = (e: any) => {
    const bidangKey = e.target.value;
    setSelectedBidang(bidangKey);
    setSelectedSeksi(FOLDER_STRUCTURE[bidangKey].subFolders[0]); // Reset ke seksi pertama di bidang tersebut
  };

  const handleDrag = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleChange = (e: any) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  const handleFiles = (newFiles: any) => {
    const fileArray = Array.from(newFiles).map((file: any) => ({
      name: file.name,
      size: (file.size / (1024 * 1024)).toFixed(2) + ' MB',
      type: file.type || 'Dokumen',
      id: Math.random().toString(36).substr(2, 9),
      unitKey: selectedBidang,
      unitName: FOLDER_STRUCTURE[selectedBidang].name,
      seksiName: selectedSeksi,
      aiDescription: '',
      fileObj: file, // Menyimpan file asli untuk fitur download & lihat
      uploadDate: new Date().toLocaleString('id-ID')
    }));
    setFiles(prev => [...prev, ...fileArray]);
    setUploadSuccess(false);
  };

  const removeFile = (id: string) => {
    setFiles(files.filter(f => f.id !== id));
  };

  const handleAutoDescription = async (fileId: string, fileName: string) => {
    setAnalyzingId(fileId);
    try {
      const prompt = `Berdasarkan nama file berikut: "${fileName}", berikan prediksi singkat (maksimal 2 kalimat) tentang isi dokumen tersebut dan rekomendasikan 3 label/tag (dipisahkan koma) untuk keperluan pengarsipan Dinas Pendidikan.`;
      const systemInstruction = "Anda adalah asisten arsiparis cerdas.";
      const result = await callGeminiAPI(prompt, systemInstruction);
      setFiles(prev => prev.map(f => 
        f.id === fileId ? { ...f, aiDescription: result } : f
      ));
    } catch (err) {
      console.error(err);
      setFiles(prev => prev.map(f => 
        f.id === fileId ? { ...f, aiDescription: 'Gagal membuat deskripsi otomatis.' } : f
      ));
    } finally {
      setAnalyzingId(null);
    }
  };

  const handleUpload = async () => {
    if (files.length === 0) return;
    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + Math.floor(Math.random() * 15) + 5; 
      });
    }, 400);

    try {
      // Save to Firebase Storage and Firestore
      for (const file of files) {
        if (!file.fileObj) continue;

        const storageRef = ref(storage, `uploads/${file.unitKey}/${file.seksiName}/${file.id}_${file.name}`);
        const uploadTask = uploadBytesResumable(storageRef, file.fileObj);

        await new Promise<void>((resolve, reject) => {
          uploadTask.on(
            'state_changed',
            (snapshot) => {
              const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
              // Update progress bar (simplified for multiple files)
              setUploadProgress(Math.round(progress));
            },
            (error) => {
              console.error("Storage upload error:", error);
              reject(error);
            },
            async () => {
              const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
              
              await addDoc(collection(db, 'files'), {
                name: file.name,
                size: file.size,
                type: file.type,
                unitKey: file.unitKey,
                seksiName: file.seksiName,
                aiDescription: file.aiDescription || '',
                status: 'Menunggu Sinkronisasi',
                uploadDate: serverTimestamp(),
                uploadedBy: user.uid,
                fileUrl: downloadURL
              });
              resolve();
            }
          );
        });
      }
      
      setUploadProgress(100);
      setTimeout(() => {
        setIsUploading(false);
        setUploadSuccess(true);
        setFiles([]); 
        setUploadProgress(0);
      }, 500);
    } catch (error) {
      console.error("Error saving to Firebase:", error);
      clearInterval(interval);
      setIsUploading(false);
      alert("Gagal mengunggah data. Pastikan Anda memiliki akses.");
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Unggah Data ke Pusat</h1>
        <p className="text-slate-500 text-sm mt-1">Sistem akan secara otomatis meletakkan file ke dalam sub-folder spesifik pada Google Drive sesuai struktur organisasi.</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 md:p-8">
        
        {/* Pilihan Folder Hierarki (Cascading Dropdown) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 bg-slate-50 p-4 rounded-lg border border-slate-100">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Pilih Unit Kerja (Folder Utama):</label>
            <select 
              value={selectedBidang}
              onChange={handleBidangChange}
              disabled={isUploading}
              className="w-full bg-white border border-slate-300 text-slate-800 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 outline-none transition-all disabled:opacity-50"
            >
              {Object.entries(FOLDER_STRUCTURE).map(([key, val]) => (
                <option key={key} value={key}>{val.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Pilih Seksi / Bagian (Sub-Folder):</label>
            <select 
              value={selectedSeksi}
              onChange={(e) => setSelectedSeksi(e.target.value)}
              disabled={isUploading}
              className="w-full bg-white border border-slate-300 text-slate-800 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 outline-none transition-all disabled:opacity-50"
            >
              {FOLDER_STRUCTURE[selectedBidang].subFolders.map((seksiName) => (
                <option key={seksiName} value={seksiName}>{seksiName}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Dropzone Area */}
        <div 
          className={`relative border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center transition-all ${
            dragActive 
              ? 'border-blue-500 bg-blue-50' 
              : 'border-slate-300 bg-white hover:bg-slate-50'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <input
            ref={inputRef}
            type="file"
            multiple
            className="hidden"
            onChange={handleChange}
            accept=".csv, .xlsx, .xls, .pdf, .doc, .docx, .zip"
          />
          
          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm mb-4 border border-slate-100">
            <UploadCloud size={32} className={dragActive ? 'text-blue-500' : 'text-slate-400'} />
          </div>
          <h3 className="text-lg font-medium text-slate-700 text-center">
            Tarik & Lepaskan file Anda di sini
          </h3>
          <p className="text-sm text-slate-500 text-center mt-2 mb-6">
            File akan diunggah ke: <br/> 
            <span className="font-semibold text-blue-600">{FOLDER_STRUCTURE[selectedBidang].name} / {selectedSeksi}</span>
          </p>
          <button 
            onClick={() => inputRef.current?.click()}
            disabled={isUploading}
            className="px-6 py-2.5 bg-white border shadow-sm border-slate-200 text-slate-700 font-medium rounded-lg hover:bg-slate-50 transition-colors disabled:opacity-50"
          >
            Pilih File dari Perangkat
          </button>
        </div>

        {/* Notifikasi Sukses */}
        {uploadSuccess && (
          <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3 animate-in fade-in zoom-in-95 duration-300">
            <CheckCircle className="text-green-600 mt-0.5 shrink-0" size={20} />
            <div>
              <h4 className="text-green-800 font-semibold text-sm">Upload Berhasil!</h4>
              <p className="text-green-600 text-sm mt-1">Dokumen telah disinkronisasikan ke Google Drive pada sub-folder yang ditentukan.</p>
            </div>
          </div>
        )}

        {/* Daftar File */}
        {files.length > 0 && !uploadSuccess && (
          <div className="mt-8">
            <h4 className="text-sm font-semibold text-slate-700 mb-3 flex justify-between items-center border-b border-slate-100 pb-2">
              <span>File Siap Diunggah ({files.length})</span>
            </h4>
            <div className="space-y-4 max-h-96 overflow-y-auto content-scrollbar pr-2">
              {files.map((file) => (
                <div key={file.id} className="flex flex-col p-3 border border-slate-200 rounded-lg bg-white shadow-sm gap-3 transition-all hover:border-blue-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 overflow-hidden">
                      <FileText size={20} className="text-blue-500 shrink-0" />
                      <div className="truncate">
                        <p className="text-sm font-semibold text-slate-700 truncate">{file.name}</p>
                        <p className="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
                          <span>{file.size}</span>
                          <span>•</span>
                          <span className="text-blue-600 font-medium truncate">
                            {file.unitName} <span className="text-slate-400">/</span> {file.seksiName}
                          </span>
                        </p>
                      </div>
                    </div>
                    {!isUploading && (
                      <button 
                        onClick={() => removeFile(file.id)}
                        className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors shrink-0"
                      >
                        <X size={16} />
                      </button>
                    )}
                  </div>
                  
                  {file.aiDescription ? (
                    <div className="bg-amber-50 rounded p-3 border border-amber-100/50 text-xs text-slate-700 relative">
                      <Sparkles size={14} className="absolute top-3 right-3 text-amber-400 opacity-50" />
                      <strong className="text-amber-700 mb-1 block">Deskripsi Arsip Otomatis (AI):</strong>
                      <div className="whitespace-pre-wrap">{file.aiDescription}</div>
                    </div>
                  ) : (
                    <div className="flex justify-end">
                      <button
                        onClick={() => handleAutoDescription(file.id, file.name)}
                        disabled={analyzingId !== null}
                        className="text-xs flex items-center gap-1.5 text-amber-600 hover:text-amber-700 bg-amber-50 px-3 py-1.5 rounded-full border border-amber-200 transition-colors disabled:opacity-50 font-medium"
                      >
                        {analyzingId === file.id ? (
                          <><Loader2 size={12} className="animate-spin" /> Menganalisis...</>
                        ) : (
                          <><Sparkles size={12} /> Buat Metadata AI ✨</>
                        )}
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Progress Bar & Tombol Action */}
            <div className="mt-6 bg-slate-50 p-4 rounded-xl border border-slate-100">
              {isUploading ? (
                <div className="space-y-3">
                  <div className="flex justify-between text-sm font-semibold">
                    <span className="text-slate-600">Menyinkronkan ke {selectedSeksi}...</span>
                    <span className="text-blue-600">{uploadProgress}%</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                    <div 
                      className="bg-blue-600 h-2.5 rounded-full transition-all duration-300 ease-out" 
                      style={{ width: `${uploadProgress}%` }}
                    ></div>
                  </div>
                </div>
              ) : (
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-500 hidden md:block">
                    *Pastikan file tidak mengandung virus/malware.
                  </span>
                  <div className="flex gap-3 w-full md:w-auto">
                    <button 
                      onClick={() => setFiles([])}
                      className="px-5 py-2 text-slate-600 font-medium rounded-lg hover:bg-slate-200 transition-colors flex-1 md:flex-none"
                    >
                      Batal
                    </button>
                    <button 
                      onClick={handleUpload}
                      className="flex justify-center items-center gap-2 px-6 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm shadow-blue-600/20 flex-1 md:flex-none"
                    >
                      <UploadCloud size={18} />
                      Mulai Sinkronisasi
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
